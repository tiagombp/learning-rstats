library(testthat)
library(fordogs)

test_check("fordogs")
